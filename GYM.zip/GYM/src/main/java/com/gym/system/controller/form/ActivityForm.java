package com.gym.system.controller.form;

import com.gym.system.dao.GymRepository;
import com.gym.system.model.Activity;
import javafx.scene.Node;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;


import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public final class ActivityForm {
    private ActivityForm() {}

    public static Optional<Activity> showAdd(boolean isDark, boolean isArabic, Function<String, String> t) {
        return showForm(t.apply("activity.add"), null, isDark, isArabic, t);
    }

    public static Optional<Activity> showEdit(GymRepository.ActivityRow existing,
                                               boolean isDark, boolean isArabic, Function<String, String> t) {
        return showForm(t.apply("activity.edit"), existing, isDark, isArabic, t);
    }

    private static Optional<Activity> showForm(String title, GymRepository.ActivityRow existing,
                                                boolean isDark, boolean isArabic, Function<String, String> t) {
        TextField arField = new TextField(existing == null ? "" : existing.nameArabic());
        TextField enField = new TextField(existing == null ? "" : existing.nameEnglish());
        TextField descField = new TextField();

        GridPane grid = grid();
        addRow(grid, 0, t.apply("activity.arabic"), arField);
        addRow(grid, 1, t.apply("activity.english"), enField);
        addRow(grid, 2, t.apply("finance.description"), descField);

        boolean saved = WizardDialog.show(title, title, isDark, isArabic, t, List.of(
                new WizardDialog.Step(title, grid, () -> {
                    if (arField.getText().isBlank() || enField.getText().isBlank()) {
                        return isArabic ? "يرجى إدخال الاسم بالعربية والإنجليزية." :
                                "Please enter both Arabic and English names.";
                    }
                    return null;
                })
        ));
        if (!saved) return Optional.empty();

        return Optional.of(new Activity(existing == null ? 0 : existing.id(),
                arField.getText().trim(), enField.getText().trim(), descField.getText().trim()));
    }


    private static GridPane grid() {
        GridPane grid = new GridPane();
        grid.setHgap(14);
        grid.setVgap(12);
        grid.setPadding(new Insets(4, 0, 0, 0));
        ColumnConstraints labels = new ColumnConstraints();
        labels.setMinWidth(150);
        labels.setPrefWidth(170);
        labels.setMaxWidth(190);
        ColumnConstraints inputs = new ColumnConstraints();
        inputs.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(labels, inputs);
        return grid;
    }

    private static void addRow(GridPane grid, int row, String label, Node input) {
        Label caption = new Label(label);
        caption.getStyleClass().add("wizard-field-label");
        caption.setWrapText(true);
        grid.add(caption, 0, row);
        if (input instanceof Control control) {
            control.setMaxWidth(Double.MAX_VALUE);
        }
        grid.add(input, 1, row);
    }

    private static boolean finish(String title, boolean dark, boolean arabic,
                                  Function<String, String> t, GridPane grid,
                                  java.util.function.Supplier<String> validator) {
        WizardDialog.Step step = new WizardDialog.Step(title, grid, validator::get);
        return WizardDialog.show(title, title, dark, arabic, t, List.of(step));
    }

}
