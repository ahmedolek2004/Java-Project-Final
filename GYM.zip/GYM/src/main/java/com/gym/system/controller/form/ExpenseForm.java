package com.gym.system.controller.form;

import javafx.scene.Node;
import javafx.scene.control.Control;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public final class ExpenseForm {
    private ExpenseForm() {}

    public record ExpenseData(String description, double amount, LocalDate date) {}

    public static Optional<ExpenseData> show(boolean isDark, boolean isArabic, Function<String, String> t) {
        TextField description = new TextField();
        TextField amount = new TextField();
        DatePicker date = new DatePicker(LocalDate.now());

        GridPane grid = grid();
        addRow(grid, 0, t.apply("finance.description"), description);
        addRow(grid, 1, t.apply("finance.amount"), amount);
        addRow(grid, 2, t.apply("finance.date"), date);

        boolean saved = WizardDialog.show(t.apply("finance.addExpense"), t.apply("finance.addExpense"),
                isDark, isArabic, t, List.of(new WizardDialog.Step(t.apply("finance.addExpense"), grid, () -> {
                    if (description.getText().isBlank()) return isArabic ? "يرجى إدخال وصف المصروف." : "Description is required.";
                    try {
                        double value = Double.parseDouble(amount.getText().trim());
                        if (!Double.isFinite(value) || value <= 0) return isArabic ? "المبلغ يجب أن يكون أكبر من صفر." : "Amount must be greater than zero.";
                    } catch (NumberFormatException ex) {
                        return isArabic ? "يرجى إدخال مبلغ صحيح." : "Enter a valid amount.";
                    }
                    if (date.getValue() == null) return isArabic ? "يرجى اختيار التاريخ." : "Please select a date.";
                    return null;
                })));
        if (!saved) return Optional.empty();

        return Optional.of(new ExpenseData(description.getText().trim(),
                Double.parseDouble(amount.getText().trim()), date.getValue()));
    }


    private static GridPane grid() {
        GridPane grid = new GridPane();
        grid.setHgap(14);
        grid.setVgap(12);
        grid.setPadding(new Insets(4, 0, 0, 0));
        ColumnConstraints labels = new ColumnConstraints();
        labels.setMinWidth(150);
        labels.setPrefWidth(170);
        labels.setMaxWidth(190);
        ColumnConstraints inputs = new ColumnConstraints();
        inputs.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(labels, inputs);
        return grid;
    }

    private static void addRow(GridPane grid, int row, String label, Node input) {
        Label caption = new Label(label);
        caption.getStyleClass().add("wizard-field-label");
        caption.setWrapText(true);
        grid.add(caption, 0, row);
        if (input instanceof Control control) {
            control.setMaxWidth(Double.MAX_VALUE);
        }
        grid.add(input, 1, row);
    }

    private static boolean finish(String title, boolean dark, boolean arabic,
                                  Function<String, String> t, GridPane grid,
                                  java.util.function.Supplier<String> validator) {
        WizardDialog.Step step = new WizardDialog.Step(title, grid, validator::get);
        return WizardDialog.show(title, title, dark, arabic, t, List.of(step));
    }

}
